# Express.js Clean Architecture with TypeScript

This is a starter template for Express.js 4.21.2 using TypeScript and following clean architecture principles.

## Project Structure

```
src/
├── presentation/           # HTTP layer (controllers, routes, middlewares)
├── domain/                # Business logic and entities
├── infrastructure/        # External services implementation
├── config/               # Configuration files
└── utils/                # Utility functions
```

## Prerequisites

- Bun.js (latest version)

## Getting Started

1. Install dependencies:
```bash
bun install
```

2. Start development server:
```bash
bun run dev
```

3. Build for production:
```bash
bun run build
```

4. Start production server:
```bash
bun run start
```

## Available Scripts

- `bun run dev` - Start development server with hot reload
- `bun run start` - Start production server
- `bun run build` - Build the project
- `bun run lint` - Run TypeScript type checking

## API Endpoints

- `GET /api/v1/health` - Health check endpoint

## License

MIT
