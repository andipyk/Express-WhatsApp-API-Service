export const swaggerDocument = {
  openapi: '3.0.0',
  info: {
    title: 'WhatsApp API Documentation',
    version: '1.0.0',
    description: 'API documentation for WhatsApp integration service'
  },
  servers: [
    {
      url: 'http://localhost:3000/api/v1',
      description: 'Local Development server'
    }
  ],
  paths: {
    '/whatsapp/send': {
      post: {
        tags: ['WhatsApp'],
        summary: 'Send WhatsApp message',
        description: 'Send a message to a WhatsApp number',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['to', 'message'],
                properties: {
                  to: {
                    type: 'string',
                    description: 'Phone number with country code (e.g., 6281234567890)',
                    example: '6281234567890'
                  },
                  message: {
                    type: 'string',
                    description: 'Message content to be sent',
                    example: 'Hello from WhatsApp API!'
                  }
                }
              }
            }
          }
        },
        responses: {
          '200': {
            description: 'Message sent successfully',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'success'
                    },
                    message: {
                      type: 'string',
                      example: 'Message sent successfully'
                    }
                  }
                }
              }
            }
          },
          '400': {
            description: 'Bad request',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'error'
                    },
                    message: {
                      type: 'string',
                      example: 'Phone number and message are required'
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    '/scheduled-messages': {
      post: {
        tags: ['Scheduled Messages'],
        summary: 'Schedule a WhatsApp message',
        description: 'Schedule a message to be sent at a specific time',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['to', 'message', 'scheduledTime'],
                properties: {
                  to: {
                    type: 'string',
                    description: 'Phone number with country code',
                    example: '6281234567890'
                  },
                  message: {
                    type: 'string',
                    description: 'Message content',
                    example: 'This is a scheduled message'
                  },
                  scheduledTime: {
                    type: 'string',
                    format: 'date-time',
                    description: 'Time to send the message (ISO string)',
                    example: '2024-01-20T15:00:00Z'
                  }
                }
              }
            }
          }
        },
        responses: {
          '201': {
            description: 'Message scheduled successfully',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'success'
                    },
                    data: {
                      type: 'object',
                      properties: {
                        id: {
                          type: 'string',
                          example: 'uuid-here'
                        },
                        to: {
                          type: 'string',
                          example: '6281234567890'
                        },
                        message: {
                          type: 'string',
                          example: 'This is a scheduled message'
                        },
                        scheduledTime: {
                          type: 'string',
                          format: 'date-time',
                          example: '2024-01-20T15:00:00Z'
                        },
                        status: {
                          type: 'string',
                          enum: ['pending', 'sent', 'failed', 'cancelled'],
                          example: 'pending'
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      },
      get: {
        tags: ['Scheduled Messages'],
        summary: 'Get all scheduled messages',
        description: 'Retrieve all scheduled messages',
        responses: {
          '200': {
            description: 'List of scheduled messages',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'success'
                    },
                    data: {
                      type: 'array',
                      items: {
                        type: 'object',
                        properties: {
                          id: {
                            type: 'string'
                          },
                          to: {
                            type: 'string'
                          },
                          message: {
                            type: 'string'
                          },
                          scheduledTime: {
                            type: 'string',
                            format: 'date-time'
                          },
                          status: {
                            type: 'string',
                            enum: ['pending', 'sent', 'failed', 'cancelled']
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    '/scheduled-messages/bulk': {
      post: {
        tags: ['Scheduled Messages'],
        summary: 'Schedule multiple messages',
        description: 'Schedule multiple messages with different times and recipients',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['messages'],
                properties: {
                  messages: {
                    type: 'array',
                    items: {
                      type: 'object',
                      required: ['to', 'message', 'scheduledTime'],
                      properties: {
                        to: {
                          type: 'string',
                          description: 'Phone number with country code',
                          example: '6281234567890'
                        },
                        message: {
                          type: 'string',
                          description: 'Message content',
                          example: 'Bulk scheduled message'
                        },
                        scheduledTime: {
                          type: 'string',
                          format: 'date-time',
                          description: 'Time to send the message',
                          example: '2024-01-20T15:00:00Z'
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        },
        responses: {
          '201': {
            description: 'Messages scheduled successfully',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'success'
                    },
                    data: {
                      type: 'array',
                      items: {
                        type: 'object',
                        properties: {
                          id: {
                            type: 'string'
                          },
                          to: {
                            type: 'string'
                          },
                          message: {
                            type: 'string'
                          },
                          scheduledTime: {
                            type: 'string',
                            format: 'date-time'
                          },
                          status: {
                            type: 'string',
                            enum: ['pending', 'sent', 'failed', 'cancelled']
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    '/scheduled-messages/{id}': {
      get: {
        tags: ['Scheduled Messages'],
        summary: 'Get a specific scheduled message',
        description: 'Retrieve details of a specific scheduled message',
        parameters: [
          {
            name: 'id',
            in: 'path',
            required: true,
            description: 'ID of the scheduled message',
            schema: {
              type: 'string'
            }
          }
        ],
        responses: {
          '200': {
            description: 'Scheduled message details',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'success'
                    },
                    data: {
                      type: 'object',
                      properties: {
                        id: {
                          type: 'string'
                        },
                        to: {
                          type: 'string'
                        },
                        message: {
                          type: 'string'
                        },
                        scheduledTime: {
                          type: 'string',
                          format: 'date-time'
                        },
                        status: {
                          type: 'string',
                          enum: ['pending', 'sent', 'failed', 'cancelled']
                        }
                      }
                    }
                  }
                }
              }
            }
          },
          '404': {
            description: 'Message not found',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'error'
                    },
                    message: {
                      type: 'string',
                      example: 'Scheduled message not found'
                    }
                  }
                }
              }
            }
          }
        }
      },
      delete: {
        tags: ['Scheduled Messages'],
        summary: 'Cancel a scheduled message',
        description: 'Cancel a pending scheduled message',
        parameters: [
          {
            name: 'id',
            in: 'path',
            required: true,
            description: 'ID of the scheduled message to cancel',
            schema: {
              type: 'string'
            }
          }
        ],
        responses: {
          '200': {
            description: 'Message cancelled successfully',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'success'
                    },
                    message: {
                      type: 'string',
                      example: 'Scheduled message cancelled'
                    }
                  }
                }
              }
            }
          },
          '404': {
            description: 'Message not found',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'error'
                    },
                    message: {
                      type: 'string',
                      example: 'Scheduled message not found'
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    '/health': {
      get: {
        tags: ['Health'],
        summary: 'Health check',
        description: 'Check if the API is running',
        responses: {
          '200': {
            description: 'Server is healthy',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    status: {
                      type: 'string',
                      example: 'success'
                    },
                    message: {
                      type: 'string',
                      example: 'Server is healthy'
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}; 