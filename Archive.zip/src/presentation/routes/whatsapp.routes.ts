import { Router } from 'express';
import { WhatsAppController } from '../controllers/whatsapp.controller';

const router = Router();
const whatsappController = new WhatsAppController();

router.post('/send', whatsappController.sendMessage);

export const whatsappRouter = router; 