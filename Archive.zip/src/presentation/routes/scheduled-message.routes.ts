import { Router } from 'express';
import { ScheduledMessageController } from '../controllers/scheduled-message.controller';

const router = Router();
const scheduledMessageController = new ScheduledMessageController();

// Schedule a single message
router.post('/', scheduledMessageController.scheduleMessage);

// Schedule multiple messages
router.post('/bulk', scheduledMessageController.scheduleBulkMessages);

// Cancel a scheduled message
router.delete('/:id', scheduledMessageController.cancelScheduledMessage);

// Get a specific scheduled message
router.get('/:id', scheduledMessageController.getScheduledMessage);

// Get all scheduled messages
router.get('/', scheduledMessageController.getAllScheduledMessages);

export const scheduledMessageRouter = router; 