import { Request, Response } from 'express';
import { WhatsAppService } from '../../infrastructure/services/whatsapp.service';
import { AppError } from '../middlewares/errorHandler';

export class WhatsAppController {
  private whatsappService: WhatsAppService;

  constructor() {
    this.whatsappService = WhatsAppService.getInstance();
  }

  public sendMessage = async (req: Request, res: Response): Promise<void> => {
    try {
      const { to, message } = req.body;

      // Check if WhatsApp is ready
      if (!this.whatsappService.isWhatsAppReady()) {
        res.status(503).json({
          status: 'error',
          message: 'WhatsApp service is not ready. Please scan the QR code first.'
        });
        return;
      }

      await this.whatsappService.sendMessage(to, message);
      
      res.status(200).json({
        status: 'success',
        message: 'Message sent successfully'
      });
    } catch (error) {
      if (error instanceof AppError) {
        res.status(error.statusCode).json({
          status: 'error',
          message: error.message
        });
        return;
      }

      console.error('Error in sendMessage controller:', error);
      res.status(500).json({
        status: 'error',
        message: 'Internal server error'
      });
    }
  };
} 