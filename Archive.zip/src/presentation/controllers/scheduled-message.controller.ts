import { Request, Response } from 'express';
import { WhatsAppService } from '../../infrastructure/services/whatsapp.service';
import { AppError } from '../middlewares/errorHandler';
import { BulkScheduleMessageDto, CreateScheduledMessageDto } from '../../domain/entities/scheduled-message';

export class ScheduledMessageController {
  private whatsappService: WhatsAppService;

  constructor() {
    this.whatsappService = WhatsAppService.getInstance();
  }

  public scheduleMessage = async (req: Request, res: Response): Promise<void> => {
    try {
      const messageDto: CreateScheduledMessageDto = req.body;
      const scheduledMessage = await this.whatsappService.scheduleMessage(messageDto);
      
      res.status(201).json({
        status: 'success',
        data: scheduledMessage
      });
    } catch (error) {
      if (error instanceof AppError) {
        res.status(error.statusCode).json({
          status: 'error',
          message: error.message
        });
        return;
      }
      res.status(500).json({
        status: 'error',
        message: 'Failed to schedule message'
      });
    }
  };

  public scheduleBulkMessages = async (req: Request, res: Response): Promise<void> => {
    try {
      const { messages }: BulkScheduleMessageDto = req.body;
      const scheduledMessages = await this.whatsappService.scheduleBulkMessages(messages);
      
      res.status(201).json({
        status: 'success',
        data: scheduledMessages
      });
    } catch (error) {
      if (error instanceof AppError) {
        res.status(error.statusCode).json({
          status: 'error',
          message: error.message
        });
        return;
      }
      res.status(500).json({
        status: 'error',
        message: 'Failed to schedule messages'
      });
    }
  };

  public cancelScheduledMessage = async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const cancelled = this.whatsappService.cancelScheduledMessage(id);
      
      if (!cancelled) {
        res.status(404).json({
          status: 'error',
          message: 'Scheduled message not found'
        });
        return;
      }

      res.status(200).json({
        status: 'success',
        message: 'Scheduled message cancelled'
      });
    } catch (error) {
      res.status(500).json({
        status: 'error',
        message: 'Failed to cancel scheduled message'
      });
    }
  };

  public getScheduledMessage = async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const message = this.whatsappService.getScheduledMessage(id);
      
      if (!message) {
        res.status(404).json({
          status: 'error',
          message: 'Scheduled message not found'
        });
        return;
      }

      res.status(200).json({
        status: 'success',
        data: message
      });
    } catch (error) {
      res.status(500).json({
        status: 'error',
        message: 'Failed to get scheduled message'
      });
    }
  };

  public getAllScheduledMessages = async (req: Request, res: Response): Promise<void> => {
    try {
      const messages = this.whatsappService.getAllScheduledMessages();
      
      res.status(200).json({
        status: 'success',
        data: messages
      });
    } catch (error) {
      res.status(500).json({
        status: 'error',
        message: 'Failed to get scheduled messages'
      });
    }
  };
} 