import { Client, LocalAuth, Message } from 'whatsapp-web.js';
import QRCode from 'qrcode';
import { AppError } from '../../presentation/middlewares/errorHandler';
import { ScheduledMessage, CreateScheduledMessageDto } from '../../domain/entities/scheduled-message';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import { Logger } from '../../utils/logger';
import { whatsappConfig } from '../../config/whatsapp.config';
import path from 'path';

// Constants
const CONSTANTS = {
  STORAGE_FILE: 'scheduled-messages.json',
  STATUS_CHECK_INTERVAL: 60000,
  LOADING_FRAMES: ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'],
  LOADING_FRAME_INTERVAL: 80,
  LOADING_DURATION: 3000,
  AUTH_PATH: '.wwebjs_auth',
  MAX_RETRIES: 3,
  RETRY_DELAY: 2000,
} as const;

// Interfaces
interface IWhatsAppService {
  sendMessage(to: string, message: string): Promise<void>;
  scheduleMessage(dto: CreateScheduledMessageDto): Promise<ScheduledMessage>;
  cancelScheduledMessage(id: string): boolean;
  getScheduledMessage(id: string): ScheduledMessage | undefined;
  getAllScheduledMessages(): ScheduledMessage[];
  isWhatsAppReady(): boolean;
}

interface IMessageStore {
  get(id: string): ScheduledMessage | undefined;
  set(id: string, message: ScheduledMessage): void;
  values(): ScheduledMessage[];
}

type WhatsAppServiceState = {
  isReady: boolean;
  isInitializing: boolean;
};

export class WhatsAppService implements IWhatsAppService {
  private client!: Client;
  private static instance: WhatsAppService;
  private state: WhatsAppServiceState = {
    isReady: false,
    isInitializing: false
  };
  private scheduledMessages: Map<string, NodeJS.Timer>;
  private messageStore: IMessageStore;
  private logger: Logger;

  private constructor() {
    this.scheduledMessages = new Map();
    this.messageStore = this.createMessageStore();
    this.logger = Logger.getInstance();
    
    this.initializeService();
    this.setupShutdownHandlers();
  }

  private createMessageStore(): IMessageStore {
    const store = new Map<string, ScheduledMessage>();
    return {
      get: (id: string) => store.get(id),
      set: (id: string, message: ScheduledMessage) => store.set(id, message),
      values: () => Array.from(store.values())
    };
  }

  private initializeService(): void {
    this.loadMessages();
    this.initializeClient();
    this.startPeriodicLogging();
  }

  private setupShutdownHandlers(): void {
    process.on('SIGTERM', this.handleShutdown.bind(this));
    process.on('SIGINT', this.handleShutdown.bind(this));
  }

  private async handleShutdown(): Promise<void> {
    try {
      if (this.client) {
        this.logger.whatsappStatus('Gracefully shutting down WhatsApp client');
        await this.client.destroy();
      }
    } catch (error) {
      this.logger.whatsappError('Error during shutdown', error);
    }
  }

  private loadMessages(): void {
    try {
      if (fs.existsSync(CONSTANTS.STORAGE_FILE)) {
        const data = fs.readFileSync(CONSTANTS.STORAGE_FILE, 'utf8');
        const messages = JSON.parse(data) as ScheduledMessage[];
        
        messages.forEach(msg => this.restoreMessage(msg));
        this.logger.whatsappStatus(`Loaded ${messages.length} scheduled messages from storage`);
      }
    } catch (error) {
      this.logger.whatsappError('Error loading messages from storage:', error);
    }
  }

  private restoreMessage(msg: ScheduledMessage): void {
    const message = {
      ...msg,
      scheduledTime: new Date(msg.scheduledTime),
      createdAt: new Date(msg.createdAt),
      updatedAt: new Date(msg.updatedAt)
    };

    this.messageStore.set(message.id, message);
    
    if (this.shouldRescheduleMessage(message)) {
      this.scheduleMessage({
        to: message.to,
        message: message.message,
        scheduledTime: message.scheduledTime.toISOString()
      }).catch(error => this.logger.whatsappError('Failed to reschedule message:', error));
    }
  }

  private shouldRescheduleMessage(message: ScheduledMessage): boolean {
    return message.status === 'pending' && message.scheduledTime.getTime() > Date.now();
  }

  private saveMessages(): void {
    try {
      const messages = this.messageStore.values();
      fs.writeFileSync(CONSTANTS.STORAGE_FILE, JSON.stringify(messages, null, 2));
    } catch (error) {
      this.logger.whatsappError('Error saving messages to storage:', error);
    }
  }

  private startPeriodicLogging(): void {
    setInterval(() => {
      this.logMessageStatus();
    }, CONSTANTS.STATUS_CHECK_INTERVAL);
  }

  private logMessageStatus(): void {
    const messages = this.messageStore.values();
    const now = new Date();
    const messageStats = this.getMessageStats(messages);
    const upcomingMessages = this.getUpcomingMessages(messages, now);

    this.logger.whatsappStatus('Scheduled Messages Status', {
      currentTime: now.toLocaleString(),
      totalMessages: messages.length,
      stats: messageStats,
      upcomingMessages
    });
  }

  private getMessageStats(messages: ScheduledMessage[]): Record<string, number> {
    return {
      pending: messages.filter(m => m.status === 'pending').length,
      sent: messages.filter(m => m.status === 'sent').length,
      failed: messages.filter(m => m.status === 'failed').length,
      cancelled: messages.filter(m => m.status === 'cancelled').length
    };
  }

  private getUpcomingMessages(messages: ScheduledMessage[], now: Date): Array<{time: string, to: string, preview: string}> {
    const next24Hours = now.getTime() + 24 * 60 * 60 * 1000;
    return messages
      .filter(m => 
        m.status === 'pending' && 
        m.scheduledTime.getTime() > now.getTime() &&
        m.scheduledTime.getTime() <= next24Hours
      )
      .sort((a, b) => a.scheduledTime.getTime() - b.scheduledTime.getTime())
      .map(m => ({
        time: m.scheduledTime.toLocaleString(),
        to: m.to,
        preview: `${m.message.substring(0, 30)}...`
      }));
  }

  private async handleMessageSending(message: ScheduledMessage): Promise<void> {
    try {
      await this.sendMessage(message.to, message.message);
      this.updateMessageStatus(message.id, 'sent');
      this.logger.whatsappStatus('Scheduled message sent successfully', { messageId: message.id });
    } catch (error) {
      this.updateMessageStatus(message.id, 'failed');
      this.logger.whatsappError('Failed to send scheduled message', { messageId: message.id, error });
    } finally {
      this.cleanupScheduledMessage(message.id);
    }
  }

  private updateMessageStatus(messageId: string, status: 'sent' | 'failed' | 'cancelled'): void {
    const message = this.messageStore.get(messageId);
    if (message) {
      message.status = status;
      message.updatedAt = new Date();
      this.messageStore.set(messageId, message);
      this.saveMessages();
    }
  }

  private cleanupScheduledMessage(messageId: string): void {
    this.scheduledMessages.delete(messageId);
    this.saveMessages();
  }

  private initializeClient(): void {
    this.logger.whatsappEvent('Initializing WhatsApp service');
    
    try {
      // Check for existing session
      const sessionPath = path.join(process.cwd(), CONSTANTS.AUTH_PATH);
      const hasExistingSession = fs.existsSync(sessionPath);

      this.client = new Client({
        ...whatsappConfig,
        authStrategy: new LocalAuth({
          clientId: 'whatsapp-api',
          dataPath: path.join(process.cwd(), CONSTANTS.AUTH_PATH)
        }),
        puppeteer: {
          ...whatsappConfig.puppeteer,
          userDataDir: hasExistingSession ? sessionPath : undefined
        }
      });

      this.setupEvents();
      
      // Initialize with retry mechanism
      const initializeWithRetry = async (retries: number = CONSTANTS.MAX_RETRIES) => {
        try {
          await this.client.initialize();
        } catch (error) {
          if (retries > 0 && !hasExistingSession) {
            this.logger.whatsappStatus(`Initialization failed, retrying... (${retries} attempts left)`);
            await new Promise(resolve => setTimeout(resolve, CONSTANTS.RETRY_DELAY));
            await initializeWithRetry(retries - 1);
          } else {
            throw error;
          }
        }
      };

      initializeWithRetry().catch(error => {
        this.logger.whatsappError('Failed to initialize WhatsApp', error);
        this.logger.whatsappStatus('All initialization attempts failed. Please restart the application.');
        this.state.isInitializing = false;
      });
    } catch (error) {
      this.logger.whatsappError('Error creating WhatsApp client', error);
      throw new AppError(500, 'Failed to create WhatsApp client');
    }
  }

  private async showLoadingIndicator(): Promise<void> {
    const frames = CONSTANTS.LOADING_FRAMES;
    let i = 0;
    
    console.clear();
    console.log('\n=== Preparing WhatsApp QR Code ===\n');
    
    return new Promise((resolve) => {
      const loadingInterval = setInterval(() => {
        process.stdout.write(`\r${frames[i]} Preparing WhatsApp client and generating QR code...`);
        i = (i + 1) % frames.length;
      }, CONSTANTS.LOADING_FRAME_INTERVAL);

      setTimeout(() => {
        clearInterval(loadingInterval);
        process.stdout.write('\r\x1b[K'); // Clear the line
        resolve();
      }, CONSTANTS.LOADING_DURATION); // Show loading for 3 seconds
    });
  }

  private setupEvents(): void {
    // QR Code Event
    this.client.on('qr', async (qr) => {
      try {
        await this.showLoadingIndicator();
        
        console.clear();
        const qrString = await QRCode.toString(qr, {
          type: 'terminal',
          small: true,
          margin: 0,
          scale: 1
        });
        
        console.log('\n=== SCAN THIS QR CODE WITH YOUR WHATSAPP ===\n');
        console.log(qrString);
        console.log('\n=========================================');
        console.log('Waiting for you to scan the QR code...\n');
        this.logger.whatsappEvent('New QR code generated and displayed');
      } catch (error) {
        this.logger.whatsappError('Failed to generate QR code', error);
      }
    });

    // Ready Event
    this.client.on('ready', () => {
      this.state.isReady = true;
      this.state.isInitializing = false;
      this.logger.whatsappStatus('WhatsApp client is ready and authenticated');
    });

    // Authentication Success Event
    this.client.on('authenticated', () => {
      this.logger.whatsappStatus('WhatsApp client authenticated successfully');
    });

    // Message Received Event
    this.client.on('message', async (msg: Message) => {
      this.logger.whatsappMessage('INCOMING', {
        from: msg.from,
        body: msg.body,
        timestamp: msg.timestamp
      });
    });

    // Message Sent Event
    this.client.on('message_create', async (msg: Message) => {
      if (msg.fromMe) {
        this.logger.whatsappMessage('OUTGOING', {
          to: msg.to,
          body: msg.body,
          timestamp: msg.timestamp
        });
      }
    });

    // Remote Session Changed Event
    this.client.on('remote_session_saved', () => {
      this.logger.whatsappStatus('WhatsApp session saved remotely');
    });

    // Authentication Failed Event
    this.client.on('auth_failure', async (error) => {
      this.state.isReady = false;
      this.logger.whatsappError('Authentication failed', error);
      await this.reinitialize();
    });

    // Disconnected Event
    this.client.on('disconnected', async (reason) => {
      this.state.isReady = false;
      this.logger.whatsappStatus('Client disconnected', { reason });
      await this.reinitialize();
    });

    // Connection Events
    this.client.on('loading_screen', (percent) => {
      if (Number(percent) < 100) {
        process.stdout.write(`\rLoading WhatsApp: ${percent}%`);
      } else {
        process.stdout.write('\r\x1b[K'); // Clear the line
      }
      this.logger.whatsappStatus('Loading WhatsApp', { percent });
    });

    this.client.on('change_state', (state) => {
      this.logger.whatsappStatus('Connection state changed', { state });
    });
  }

  private async reinitialize(): Promise<void> {
    if (this.state.isInitializing) {
      this.logger.whatsappStatus('Already reinitializing. Please wait...');
      return;
    }
    
    this.state.isInitializing = true;
    this.state.isReady = false;
    this.logger.whatsappStatus('Reinitializing WhatsApp client');
    
    try {
      if (this.client) {
        await this.client.destroy();
      }

      // Only clear auth if explicitly requested
      if (process.env.FORCE_NEW_QR === 'true') {
        const authPath = CONSTANTS.AUTH_PATH;
        if (fs.existsSync(authPath)) {
          fs.rmSync(authPath, { recursive: true });
          this.logger.whatsappStatus('Cleared previous session data');
        }
      }

      await new Promise(resolve => setTimeout(resolve, CONSTANTS.RETRY_DELAY));
      this.initializeClient();
    } catch (error) {
      this.logger.whatsappError('Error reinitializing client', error);
      this.state.isInitializing = false;
      throw new AppError(500, 'Failed to reinitialize WhatsApp client');
    }
  }

  public static getInstance(): WhatsAppService {
    if (!WhatsAppService.instance) {
      WhatsAppService.instance = new WhatsAppService();
    }
    return WhatsAppService.instance;
  }

  public async sendMessage(to: string, message: string): Promise<void> {
    if (!this.state.isReady) {
      this.logger.whatsappStatus('Service not ready, reinitializing');
      await this.reinitialize();
      throw new AppError(503, 'Please scan the QR code and try again');
    }

    this.validateMessageInput(to, message);
    const formattedNumber = this.formatPhoneNumber(to);
    await this.validatePhoneNumber(formattedNumber);

    try {
      await this.client.sendMessage(formattedNumber, message);
      this.logger.whatsappMessage('OUTGOING', {
        to: formattedNumber,
        body: message,
        timestamp: Date.now()
      });
    } catch (error) {
      await this.handleSendMessageError(error);
    }
  }

  private validateMessageInput(to: string, message: string): void {
    if (!to || !message) {
      throw new AppError(400, 'Phone number and message are required');
    }
  }

  private async validatePhoneNumber(phoneNumber: string): Promise<void> {
    const numberExists = await this.client.isRegisteredUser(phoneNumber);
    if (!numberExists) {
      this.logger.whatsappError('Invalid WhatsApp number', { number: phoneNumber });
      throw new AppError(404, 'Phone number is not registered on WhatsApp');
    }
  }

  private async handleSendMessageError(error: unknown): Promise<never> {
    this.logger.whatsappError('Failed to send WhatsApp message', error);
    
    if (this.isSessionError(error)) {
      this.logger.whatsappStatus('Session expired, reinitializing');
      await this.reinitialize();
      throw new AppError(503, 'Session expired. Please scan the new QR code.');
    }
    
    throw new AppError(500, 'Failed to send WhatsApp message');
  }

  private isSessionError(error: unknown): boolean {
    return error instanceof Error && 
           (error.message.includes('Session') || error.message.includes('Connection'));
  }

  private formatPhoneNumber(phone: string): string {
    // Remove any non-digit characters
    const cleanNumber = phone.replace(/\D/g, '');
    
    // Check if number already has @c.us
    if (cleanNumber.includes('@c.us')) {
      return cleanNumber;
    }

    // Add country code if not present
    const numberWithCountryCode = cleanNumber.startsWith('62') 
      ? cleanNumber 
      : `62${cleanNumber.startsWith('0') ? cleanNumber.slice(1) : cleanNumber}`;

    return `${numberWithCountryCode}@c.us`;
  }

  public isWhatsAppReady(): boolean {
    return this.state.isReady;
  }

  public async scheduleMessage(dto: CreateScheduledMessageDto): Promise<ScheduledMessage> {
    if (!this.state.isReady) {
      this.logger.whatsappStatus('Service not ready, reinitializing');
      await this.reinitialize();
      throw new AppError(503, 'Please scan the QR code and try again');
    }

    const scheduledTime = new Date(dto.scheduledTime);
    this.validateScheduledTime(scheduledTime);

    const message = this.createScheduledMessage(dto, scheduledTime);
    const timeoutId = this.scheduleMessageTimeout(message);

    this.scheduledMessages.set(message.id, timeoutId);
    this.messageStore.set(message.id, message);
    this.saveMessages();
    this.logMessageStatus();

    return message;
  }

  private validateScheduledTime(scheduledTime: Date): void {
    if (scheduledTime.getTime() <= Date.now()) {
      throw new AppError(400, 'Scheduled time must be in the future');
    }
  }

  private createScheduledMessage(dto: CreateScheduledMessageDto, scheduledTime: Date): ScheduledMessage {
    return {
      id: uuidv4(),
      to: this.formatPhoneNumber(dto.to),
      message: dto.message,
      scheduledTime,
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date()
    };
  }

  private scheduleMessageTimeout(message: ScheduledMessage): NodeJS.Timer {
    const delay = message.scheduledTime.getTime() - Date.now();
    return setTimeout(() => this.handleMessageSending(message), delay);
  }

  public async scheduleBulkMessages(messages: CreateScheduledMessageDto[]): Promise<ScheduledMessage[]> {
    if (!this.state.isReady) {
      throw new AppError(503, 'WhatsApp service is not ready. Please scan the QR code first.');
    }

    const scheduledMessages = await Promise.all(
      messages.map(msg => this.scheduleMessage(msg))
    );

    return scheduledMessages;
  }

  public cancelScheduledMessage(id: string): boolean {
    const timeout = this.scheduledMessages.get(id);
    const message = this.messageStore.get(id);
    
    if (!timeout || !message || message.status !== 'pending') {
      return false;
    }

    clearTimeout(timeout);
    this.scheduledMessages.delete(id);
    
    message.status = 'cancelled';
    message.updatedAt = new Date();
    this.saveMessages();
    this.logMessageStatus();

    return true;
  }

  public getScheduledMessage(id: string): ScheduledMessage | undefined {
    return this.messageStore.get(id);
  }

  public getAllScheduledMessages(): ScheduledMessage[] {
    return this.messageStore.values();
  }
} 