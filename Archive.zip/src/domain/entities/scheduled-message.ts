export interface ScheduledMessage {
  id: string;
  to: string;
  message: string;
  scheduledTime: Date;
  status: 'pending' | 'sent' | 'failed' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateScheduledMessageDto {
  to: string;
  message: string;
  scheduledTime: string; // ISO string format
}

export interface BulkScheduleMessageDto {
  messages: {
    to: string;
    message: string;
    scheduledTime: string;
  }[];
} 